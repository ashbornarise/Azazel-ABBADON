import numpy as np, pandas as pd

def backtest(prices: pd.Series, fast=20, slow=100, cost=0.001):
    """Croisement de moyennes mobiles. cost = frais+glissement par changement de position (0.001 = 0,1 %)."""
    fast_ma = prices.rolling(fast).mean()
    slow_ma = prices.rolling(slow).mean()
    signal = (fast_ma > slow_ma).astype(int)          # 1 = investi, 0 = cash
    position = signal.shift(1).fillna(0)              # on agit le LENDEMAIN : pas de triche sur le futur
    ret = prices.pct_change().fillna(0)
    trades = position.diff().abs().fillna(0)
    strat = position * ret - trades * cost
    equity = (1 + strat).cumprod()
    buyhold = (1 + ret).cumprod()
    return equity, buyhold, int(trades.sum())

def stats(equity):
    r = equity.pct_change().dropna()
    years = len(r) / 252
    cagr = equity.iloc[-1] ** (1 / years) - 1
    sharpe = r.mean() / r.std() * np.sqrt(252) if r.std() > 0 else 0
    maxdd = (equity / equity.cummax() - 1).min()
    return f"rendement/an {cagr:6.1%} | Sharpe {sharpe:5.2f} | pire baisse {maxdd:6.1%}"

if __name__ == "__main__":
    # données SIMULÉES (marche aléatoire) pour tester le code : remplace par de vraies données
    rng = np.random.default_rng(1)
    idx = pd.bdate_range("2015-01-01", periods=2500)
    prices = pd.Series(100 * np.exp(np.cumsum(rng.normal(0.0003, 0.01, len(idx)))), index=idx)
    split = int(len(prices) * 0.7)                    # 70 % pour construire, 30 % jamais touchés pour juger
    for name, p in [("construction", prices[:split]), ("test final", prices[split:])]:
        eq, bh, n = backtest(p)
        print(f"{name:13s} stratégie: {stats(eq)} | {n} trades")
        print(f"{'':13s} acheter-garder: {stats(bh)}")
