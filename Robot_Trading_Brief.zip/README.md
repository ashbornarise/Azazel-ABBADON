# Robot de trading « Rex Clemens Capital » — banc d'essai et module de survie

Brief pour Claude Code. Construire d'abord ce qui protège le compte (module de survie) et ce qui met le robot à l'épreuve (banc de stress). La stratégie de trading vient ensuite, branchée sur ces deux protections. Fichier de départ fourni : `backtest.py` (croisement de moyennes mobiles, testé sur données simulées).

## 1. Contexte et principe directeur

Clément (étudiant en génie mécanique, fondateur de Nova Luz et de Cauri Charts) veut apprendre à construire un robot de trading de façon rigoureuse. Ce n'est pas, à ce stade, une source de revenus.

Principe : **la survie du compte passe avant le gain.** La vie du robot, c'est l'argent du compte. Un robot qui perd tout est mort ; un robot qui ne gagne pas peut encore apprendre.

Règles de fond :
- Le robot ne prédit pas le prix. Il estime avec prudence, limite ce qu'il risque, coupe ses pertes et mesure en continu s'il se trompe plus que prévu.
- Un bon résultat sur un seul test ne prouve rien. Sur des données purement aléatoires, une stratégie a affiché un ratio de Sharpe de 1,05 sur la période de test, par chance. Le banc d'essai doit donc comporter une **stratégie témoin aléatoire** qui ne doit jamais avoir l'air bonne.
- Il n'y a aucun argent réel, aucune connexion à un courtier et aucune clé d'API dans ce projet tant que Clément ne l'a pas décidé explicitement (voir section 9).

## 2. Architecture

```
trading-robot/
  README.md
  config.toml              # tous les seuils de survie, jamais codés en dur dans le code
  data/                    # données en cache, avec source et date de téléchargement
  src/
    data.py                # chargement (yfinance, ccxt), nettoyage, contrôles de qualité
    survie.py              # MODULE 1 : règles de survie, indépendant de la stratégie
    watchdog.py            # arrêt d'urgence : processus séparé du robot
    backtest.py            # MODULE 3 : moteur de test (frais, glissement, pas de triche sur le futur)
    stress.py              # MODULE 2 : rejeu de crises, Monte Carlo, chocs synthétiques
    strategies/
      base.py              # interface : une stratégie ne renvoie qu'une exposition cible entre 0 et 1
      buy_hold.py          # référence
      ma_cross.py          # exemple (déjà écrit dans backtest.py)
      random_control.py    # stratégie témoin aléatoire
    report.py              # rapport clair avec verdict réussi / échoué
  tests/                   # tests automatiques de chaque règle de survie
```

Une stratégie **ne peut pas contourner** la couche de survie : elle propose une exposition, `survie.py` la réduit, la refuse ou impose zéro.

## 3. Module 1 : survie (règles en dur)

Valeurs par défaut à mettre dans `config.toml` (Clément pourra les changer, la liste est prudente) :

| Règle | Valeur par défaut |
|---|---|
| Risque maximal par trade | 1 % du compte |
| Levier | interdit (exposition maximale 1,0) |
| Perte maximale sur une journée | 3 % du compte, puis arrêt jusqu'au lendemain |
| Perte maximale depuis le plus haut du compte | 10 % : arrêt complet, remise à zéro uniquement par Clément |
| Taille maximale d'une position | 25 % du compte |
| Données manquantes, périmées, fausses (prix à 0, saut impossible, horodatage ancien) | passage à l'état « liquide » (aucune position), aucun nouveau trade |
| Perte de connexion ou erreur répétée du courtier | idem |

Chaque règle a un **test automatique** qui la déclenche volontairement et vérifie la réaction.

### Arrêt d'urgence indépendant
Le principe appris en GMP : l'arrêt doit rester fonctionnel quand la machine qui commande est tombée en panne. Pour le robot :
- `watchdog.py` est un **processus séparé** qui surveille le compte et peut tout arrêter même si le robot plante ;
- quand le mode réel existera : ordres d'arrêt posés **chez le courtier** (côté serveur, pas dans le robot), clé d'accès sans droit de retrait, et une procédure manuelle d'une seconde pour couper la clé ;
- l'arrêt d'urgence doit pouvoir se déclencher à la main (fichier drapeau, commande simple) et se tester régulièrement.

## 4. Module 2 : banc de stress

Un robot passe le banc ou ne passe pas. Le critère n'est pas le gain, c'est : **le compte survit et aucune règle de survie n'est violée.**

1. **Rejeu des vraies crises** : 2008, mars 2020, effondrement de Terra/Luna (2022), faillite de FTX, krach éclair d'août 2015. Données à récupérer et à documenter (source, période).
2. **Monte Carlo** : rééchantillonnage de morceaux d'historique (par blocs pour garder la persistance) pour fabriquer des milliers de marchés plausibles.
3. **Chocs synthétiques** : chute de 20 % en une fois ; frais et écarts de prix multipliés par 2 ou 5 ; prix qui saute sans cotations intermédiaires ; données fausses ; panne de connexion de 30 minutes en pleine position ; volatilité multipliée par 3.
4. **Critères de réussite** (à rendre configurables) : aucune violation des règles de survie ; perte maximale sous le seuil dans au moins 95 % des scénarios simulés ; aucun scénario où le compte tombe à zéro.

## 5. Module 3 : moteur de test

- Le signal du jour est exécuté **le lendemain** (déjà fait dans `backtest.py`). Aucun accès à des données futures.
- Frais et glissement obligatoires et réalistes (par défaut 0,1 % par changement de position).
- Séparation 70 % construction / 30 % test final, ce dernier jamais touché pendant la construction. Ajouter ensuite une validation **walk-forward** (fenêtres glissantes).
- Mesures : rendement annuel, ratio de Sharpe, pire baisse, nombre de trades, comparaison à « acheter et garder ».
- Toute stratégie doit être comparée à la **stratégie témoin aléatoire** sur plusieurs actifs et plusieurs périodes.

## 6. Fiche d'hypothèse (à remplir avant d'écrire une stratégie)

1. Quel avantage cette stratégie est-elle censée avoir, et pourquoi existerait-il ?
2. Qui perd de l'autre côté du trade ?
3. Qu'est-ce qui la ferait cesser de marcher ?
4. Combien de trades faut-il pour distinguer un vrai avantage de la chance ?

Une stratégie sans fiche remplie n'est pas acceptée.

## 7. Feuille de route

| Phase | Contenu | Critère de passage |
|---|---|---|
| 0 | Squelette du dépôt, `config.toml`, données en cache | Les tests automatiques de base passent |
| 1 | `survie.py`, `watchdog.py` et leurs tests | Chaque règle se déclenche et est vérifiée |
| 2 | `stress.py` et rapport | Le banc tourne sur la stratégie témoin et sur « acheter et garder » |
| 3 | Stratégies de base, témoin aléatoire | Le témoin aléatoire n'a pas l'air bon ; verdict honnête sur le reste |
| 4 | Trading sur papier (compte de démonstration), 3 à 6 mois | Résultats cohérents avec les tests, aucune violation de survie |
| 5 | Réel avec une somme minuscule | **Décision explicite de Clément uniquement** |

## 8. Pile technique conseillée

Python 3.11+, `pandas`, `numpy`, tests avec `pytest`. Données : `yfinance` (prix journaliers) et `ccxt` (cryptos). Pas de bibliothèque de backtest externe au début : écrire le moteur soi-même pour comprendre ce qu'il fait ; `vectorbt` ou `backtesting.py` pourront servir plus tard comme comparaison. Pas d'apprentissage par renforcement avant la phase 4 : un agent apprend les défauts du simulateur.

## 9. Interdits

- Ne jamais utiliser d'argent réel, ne jamais créer de compte courtier, ne jamais demander ni stocker de clé d'API sans validation explicite de Clément.
- Ne jamais utiliser de levier.
- Ne jamais désactiver ou assouplir une règle de survie pour améliorer un résultat de test.
- Ne jamais présenter un résultat de test comme une promesse de gain. Chaque rapport doit mentionner les limites (données passées, frais estimés, risque de surajustement).
- Ne pas publier, déployer ni soumettre quoi que ce soit à une plateforme externe sans validation de Clément.

## 10. Points ouverts (en attente de Clément)

- Marché visé : actions, cryptos, devises ?
- Rythme : un trade par jour, par semaine, plus lent ?
- Perte maximale que Clément peut accepter sans que cela lui fasse mal (somme en euros). Les seuils de survie en dépendent.
- Courtier et pays de résidence fiscale (réglementation et impôts à vérifier avant la phase 5).
- Statut des gains : à étudier avec un conseiller avant tout argent réel.

## 11. Première tâche

Créer le dépôt avec l'arborescence de la section 2, mettre `backtest.py` fourni dans `src/`, écrire `config.toml` avec les valeurs de la section 3, puis implémenter `survie.py` et ses tests (phase 1). Montrer le résultat et les tests passés avant de commencer le banc de stress.
